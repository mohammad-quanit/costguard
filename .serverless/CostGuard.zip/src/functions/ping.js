exports.run = async() => {
  const time = new Date();
  console.log(`Your cron function ran at ${time}`);
  return {
    statusCode: 200,
    body: JSON.stringify({ message: 'Ping received' }),
  };
};
